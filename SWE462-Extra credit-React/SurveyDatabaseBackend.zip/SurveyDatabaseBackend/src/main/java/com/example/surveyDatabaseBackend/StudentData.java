package com.example.surveyDatabaseBackend;

import java.util.Objects;

import jakarta.persistence.*;

@Entity
@Table(name="students")
public class StudentData {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	@Column(name="first_name", nullable=false)
	private String firstName;

	@Override
	public int hashCode() {
		return Objects.hash(additionalComments, atmosphere, campus, city, dateOfSurvey, dormRooms, email, firstName, id,
				interestSource, lastName, location, phoneNumber, recommendLikelihood, sports, state, streetAddress,
				students, zip);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StudentData other = (StudentData) obj;
		return Objects.equals(additionalComments, other.additionalComments)
				&& Objects.equals(atmosphere, other.atmosphere) && Objects.equals(campus, other.campus)
				&& Objects.equals(city, other.city) && Objects.equals(dateOfSurvey, other.dateOfSurvey)
				&& Objects.equals(dormRooms, other.dormRooms) && Objects.equals(email, other.email)
				&& Objects.equals(firstName, other.firstName) && id == other.id
				&& Objects.equals(interestSource, other.interestSource) && Objects.equals(lastName, other.lastName)
				&& Objects.equals(location, other.location) && Objects.equals(phoneNumber, other.phoneNumber)
				&& Objects.equals(recommendLikelihood, other.recommendLikelihood)
				&& Objects.equals(sports, other.sports) && Objects.equals(state, other.state)
				&& Objects.equals(streetAddress, other.streetAddress) && Objects.equals(students, other.students)
				&& Objects.equals(zip, other.zip);
	}

	public String getStudents() {
		return students;
	}

	public void setStudents(String students) {
		this.students = students;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCampus() {
		return campus;
	}

	public void setCampus(String campus) {
		this.campus = campus;
	}

	public String getAtmosphere() {
		return atmosphere;
	}

	public void setAtmosphere(String atmosphere) {
		this.atmosphere = atmosphere;
	}

	public String getDormRooms() {
		return dormRooms;
	}

	public void setDormRooms(String dormRooms) {
		this.dormRooms = dormRooms;
	}

	public String getSports() {
		return sports;
	}

	public void setSports(String sports) {
		this.sports = sports;
	}

	public String getInterestSource() {
		return interestSource;
	}

	public void setInterestSource(String interestSource) {
		this.interestSource = interestSource;
	}

	public String getRecommendLikelihood() {
		return recommendLikelihood;
	}

	public void setRecommendLikelihood(String recommendLikelihood) {
		this.recommendLikelihood = recommendLikelihood;
	}

	public String getAdditionalComments() {
		return additionalComments;
	}

	public void setAdditionalComments(String additionalComments) {
		this.additionalComments = additionalComments;
	}

	@Column(name="last_name", nullable=false)
	private String lastName;
	
	@Column(name="street_Adress", nullable=false)
	private String streetAddress;
	
	@Column(name="city", nullable=false)
	private String city;
	
	@Column(name="state", nullable=false)
	private String state;
	
	@Column(name="zip", nullable=false)
	private String zip;
	
	@Column(name="phone_number", nullable=false)
	private String phoneNumber;
	
	@Column(name="email", nullable=false)
	private String email;
	
	@Column(name="date_of_survey", nullable=false)
	private String dateOfSurvey;
	
	 @Column(name="students", nullable=true)
	 private String students;
	 
	 @Column(name="location", nullable=true)
	 private String location;
	 
	 @Column(name="campus", nullable=true)
	 private String campus;
	 
	 @Column(name="atmosphere", nullable=true)
	 private String atmosphere;
	 
	 @Column(name="dorm_rooms", nullable=true)
	 private String dormRooms;
	 
	 @Column(name="sports", nullable=true)
	 private String sports;
	
	@Column(name="interest", nullable=false)
	private String interestSource;
	
	@Column(name="recommend", nullable=false)
	private String recommendLikelihood;
	
	@Column(name="comments")
	private String additionalComments;
	
	
	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDateOfSurvey() {
		return dateOfSurvey;
	}

	public void setDateOfSurvey(String dateOfSurvey) {
		this.dateOfSurvey = dateOfSurvey;
	}

	public long getId() {
		return id;
	}
	
	public void setId(long id) {
		this.id = id;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

}