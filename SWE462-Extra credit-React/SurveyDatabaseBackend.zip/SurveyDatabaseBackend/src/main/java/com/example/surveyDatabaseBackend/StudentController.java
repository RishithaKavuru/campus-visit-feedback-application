package com.example.surveyDatabaseBackend;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/surveyform")
@CrossOrigin(origins = "http://localhost:3000")
public class StudentController {
	
	@Autowired
	private StudentService studentService;

	public StudentController(StudentService studentService) {
		super();
		this.studentService = studentService;
	}
	
	
	@PostMapping
	public ResponseEntity<StudentData> saveStudent(@RequestBody StudentData student){
		
		System.out.println("Reached post method");
		try {
	        
	        return new ResponseEntity<StudentData>(studentService.saveStudent(student), HttpStatus.CREATED);
	    } catch (Exception e) {
	    	System.out.println(e.getMessage());
	        return new ResponseEntity<StudentData>(studentService.saveStudent(student), HttpStatus.BAD_REQUEST);
	    }
	}
	
	@GetMapping
	public List<StudentData> getAllStudents(){
		return studentService.getAllStudents();
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<StudentData> getStudentById(@PathVariable("id") long studentId){
		return new ResponseEntity<StudentData>(studentService.getStudentById(studentId), HttpStatus.OK);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<StudentData> updateStudent(@PathVariable("id") long id, @RequestBody StudentData student){
		return new ResponseEntity<StudentData>(studentService.updateStudent(student, id), HttpStatus.OK);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteStudent(@PathVariable("id") long id){
		studentService.deleteStudent(id);	
		
		return new ResponseEntity<>( HttpStatus.NO_CONTENT);
		
	}
}
