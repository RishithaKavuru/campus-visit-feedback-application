package com.example.surveyDatabaseBackend;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

@Service
public class StudentServiceImpl implements StudentService{

	public StudentRepository studentRepository;
	
	
	public StudentServiceImpl(StudentRepository studentRepository) {
		super();
		this.studentRepository = studentRepository;
	}

	@Override
	public StudentData saveStudent(StudentData student) {
		return studentRepository.save(student);
	}

	@Override
	public List<StudentData> getAllStudents() {
		return studentRepository.findAll();
	}

	@Override
	public StudentData getStudentById(long id) {
		Optional<StudentData> student = studentRepository.findById(id);
		
		if (student.isPresent()) {
			return student.get();
		}
		else {
			throw new ResourceNotFoundException("Student", "ID", id);
		}
	}

	@Override
	public StudentData updateStudent(StudentData student, long id) {
		StudentData existingStudent = studentRepository.findById(id).orElseThrow(
				() -> new ResourceNotFoundException("student", "Id", id));
		existingStudent.setFirstName(student.getFirstName());
		existingStudent.setLastName(student.getLastName());
		existingStudent.setStreetAddress(student.getStreetAddress());
		existingStudent.setCity(student.getCity());
		existingStudent.setState(student.getState());
		existingStudent.setZip(student.getZip());
		existingStudent.setPhoneNumber(student.getPhoneNumber());
		existingStudent.setEmail(student.getEmail());
		existingStudent.setDateOfSurvey(student.getDateOfSurvey());
		existingStudent.setInterestSource(student.getInterestSource());
		existingStudent.setRecommendLikelihood(student.getRecommendLikelihood());;
		existingStudent.setAdditionalComments(student.getAdditionalComments());
		existingStudent.setStudents(student.getStudents());
		existingStudent.setLocation(student.getLocation());
		existingStudent.setCampus(student.getCampus());
		existingStudent.setAtmosphere(student.getAtmosphere());
		existingStudent.setDormRooms(student.getDormRooms());
		existingStudent.setSports(student.getSports());
		
		studentRepository.save(existingStudent);
		
		return existingStudent;
	}

	@Override
	public void deleteStudent(long id) {
		studentRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Student", "Id", id));
		
		studentRepository.deleteById(id);
	}

}

