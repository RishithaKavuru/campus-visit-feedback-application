package com.example.surveyDatabaseBackend;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<StudentData, Long>{
	
}

