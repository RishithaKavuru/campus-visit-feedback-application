package com.example.surveyDatabaseBackend;

import java.util.List;

public interface StudentService {
	StudentData saveStudent(StudentData student);
	List<StudentData> getAllStudents();
	StudentData getStudentById(long id);
	StudentData updateStudent(StudentData student, long id);
	void deleteStudent(long id);

}